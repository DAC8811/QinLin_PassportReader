/*
 * JP2.h
 *
 *  Created on: Sep 11, 2018
 *      Author: echo
 */

#ifndef JP2_H_
#define JP2_H_

#include "Ptypes.h"
char jp2_to_bmp(std::string &data, std::string filename);

#endif /* JP2_H_ */
